# DAYZ GATE — GitHub + Railway + Nitrado

Bot Discord + Dashboard web pour gérer une whitelist DayZ sur **PC, Xbox et PlayStation**.

## Fonctionnalités

- `/whitelist` depuis Discord
- PC / Xbox / PlayStation
- Dashboard premium noir/rouge
- Accepter / refuser / supprimer une demande
- Attribution automatique du rôle Discord whitelist
- Statistiques et recherche
- Bouton « Rejoindre le Discord »
- Connexion du compte propriétaire **Nitrado via OAuth2**
- Liste des services Nitrado du propriétaire
- Sélection du serveur depuis le Dashboard
- Stockage chiffré des tokens Nitrado côté serveur
- **DayZ PC : ajout automatique dans `dayzstandalone/whitelist.txt` après validation**
- Xbox / PlayStation : la validation reste enregistrée dans DayZ Gate ; la gestion de whitelist console reste via l’interface Web Nitrado tant qu’une méthode API documentée équivalente n’est pas utilisée.

## Important pour DayZ PC

Nitrado demande un **UID DayZ de 44 caractères** dans `whitelist.txt`.
La commande Discord demande donc :

- PC → UID DayZ 44 caractères
- Xbox → Gamertag
- PlayStation → ID PSN

## Déploiement GitHub → Railway

### 1. Mettre le projet sur GitHub

Le fichier `.gitignore` exclut déjà `.env`, la base locale et `node_modules`.
Ne mets jamais les tokens Discord, secrets Nitrado ou mots de passe dans GitHub.

### 2. Créer le service Railway

- New Project → Deploy from GitHub Repo
- Sélectionne le dépôt DayZ Gate
- Railway lance `npm start`
- Le healthcheck est `/health`

### 3. Ajouter un Volume Railway

SQLite doit être persistant.

- Ajoute un Volume au service
- Mount Path : `/data`
- Variable : `DB_PATH=/data/dayzgate.db`

Sans Volume, la base peut être perdue lors d’un redéploiement.

### 4. Ajouter les variables Railway

Copie les valeurs de `.env.example` dans Railway → Variables.

Variables indispensables :

- `DISCORD_TOKEN`
- `DISCORD_CLIENT_ID`
- `DISCORD_GUILD_ID`
- `WHITELIST_ROLE_ID`
- `SESSION_SECRET`
- `DASHBOARD_USER`
- `DASHBOARD_PASSWORD`
- `PUBLIC_BASE_URL`
- `NITRADO_CLIENT_ID`
- `NITRADO_CLIENT_SECRET`
- `NITRADO_TOKEN_SECRET`

Exemple :

`PUBLIC_BASE_URL=https://ton-projet.up.railway.app`

### 5. Configurer l’application OAuth Nitrado

Dans le portail développeur Nitrado, crée une application OAuth et utilise comme redirect URI :

`https://ton-projet.up.railway.app/auth/nitrado/callback`

Scopes utilisés :

`user_info service`

Le mot de passe Nitrado n’est jamais enregistré par DayZ Gate. Le propriétaire s’authentifie directement chez Nitrado et autorise l’application.

### 6. Connecter Nitrado

Dans le Dashboard :

1. Clique **Connecter Nitrado**
2. Connecte le compte propriétaire chez Nitrado
3. Autorise DayZ Gate
4. Choisis le service Nitrado
5. Vérifie le fichier `dayzstandalone/whitelist.txt`
6. Enregistre

Quand une demande **PC** est approuvée, DayZ Gate tente alors d’ajouter automatiquement l’UID au fichier Nitrado. La whitelist doit déjà être activée (`enableWhitelist = 1`) et Nitrado recommande un redémarrage du serveur après modification.

## Fonctionnement

`Joueur Discord → /whitelist → demande en attente → admin valide → rôle Discord → synchro Nitrado PC`

Pour Xbox/PlayStation :

`Joueur Discord → /whitelist → admin valide → rôle Discord → statut console à appliquer dans le Web Interface Nitrado`

## Lancement local

```bash
cp .env.example .env
npm install
npm start
```

Dashboard : `http://localhost:3000`

Pour tester OAuth localement, il faut enregistrer une redirect URI locale chez Nitrado ou utiliser l’URL Railway.

## Sécurité

- `.env` ignoré par Git
- tokens Nitrado chiffrés en AES-256-GCM dans la base
- état OAuth aléatoire anti-CSRF
- cookies session HTTP-only
- HTTPS fourni par Railway en production
- ne partage jamais `NITRADO_CLIENT_SECRET`, `NITRADO_TOKEN_SECRET` ou `DISCORD_TOKEN`
