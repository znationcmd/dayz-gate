# Checklist Railway — DayZ Gate

1. Créer le dépôt GitHub et envoyer tous les fichiers du dossier `dayz-gate`.
2. Railway → New Project → Deploy from GitHub Repo.
3. Ajouter un Volume Railway monté sur `/data`.
4. Ajouter `DB_PATH=/data/dayzgate.db`.
5. Générer le domaine Railway public.
6. Mettre ce domaine dans `PUBLIC_BASE_URL`.
7. Créer/configurer l'application OAuth Nitrado avec callback :
   `https://TON-DOMAINE/auth/nitrado/callback`
8. Ajouter les secrets Discord et Nitrado dans Railway → Variables.
9. Déployer.
10. Ouvrir le Dashboard et cliquer « Connecter Nitrado ».
11. Sélectionner le service DayZ.
12. Vérifier `dayzstandalone/whitelist.txt`.
13. Sur DayZ PC, vérifier que `enableWhitelist = 1`.
14. Tester `/whitelist` avec un UID DayZ PC de 44 caractères.
15. Valider la demande depuis le Dashboard.
