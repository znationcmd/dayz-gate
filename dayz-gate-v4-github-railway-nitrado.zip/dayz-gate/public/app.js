const $ = s => document.querySelector(s);

const loginView = $("#loginView");
const dashboardView = $("#dashboardView");
const rows = $("#rows");
let latestRows = [];

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || "Erreur");
  }
  return res.json();
}

async function loadPublicConfig() {
  try {
    const cfg = await api("/api/public-config");
    const buttons = [$("#joinDiscordBtn"), $("#joinDiscordHero")].filter(Boolean);
    if (cfg.discordInviteUrl) {
      buttons.forEach(btn => {
        btn.href = cfg.discordInviteUrl;
        btn.classList.remove("is-disabled");
      });
    } else {
      buttons.forEach(btn => {
        btn.href = "#";
        btn.classList.add("is-disabled");
        btn.title = "Ajoute DISCORD_INVITE_URL dans Railway";
      });
    }
  } catch (e) {
    console.warn("Impossible de charger le lien Discord", e);
  }
}

function statusBadge(status) {
  const map = {
    pending: ["En attente", "pending"],
    approved: ["Approuvé", "approved"],
    rejected: ["Refusé", "rejected"]
  };
  const [label, cls] = map[status] || [status, ""];
  return `<span class="badge ${cls}">${label}</span>`;
}

function syncBadge(status, message) {
  const key = status || "none";
  const labels = {
    synced: "Synchronisé",
    already_present: "Déjà présent",
    error: "Erreur",
    console_manual: "Console",
    not_applicable: "—",
    none: "—"
  };
  return `<span class="sync-badge sync-${escapeHtml(key)}" title="${escapeHtml(message || "")}">${escapeHtml(labels[key] || key)}</span>`;
}

function escapeHtml(v) {
  return String(v ?? "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

function safeDate(v) {
  if (!v) return "-";
  const d = new Date(v + "Z");
  return isNaN(d.getTime()) ? "-" : d.toLocaleString();
}

function updatePlatformCards(data) {
  const counts = { PC: 0, Xbox: 0, PlayStation: 0 };
  for (const row of data) {
    if (counts[row.platform] !== undefined) counts[row.platform] += 1;
  }
  $("#pPC").textContent = counts.PC;
  $("#pXbox").textContent = counts.Xbox;
  $("#pPlayStation").textContent = counts.PlayStation;
}

function setBar(id, value, max) {
  const pct = max > 0 ? Math.max(4, Math.round((value / max) * 100)) : 0;
  $(id).style.width = `${pct}%`;
}

async function loadStats() {
  const s = await api("/api/stats");
  $("#sTotal").textContent = s.total;
  $("#sPending").textContent = s.pending;
  $("#sApproved").textContent = s.approved;
  $("#sRejected").textContent = s.rejected;
  const max = Math.max(s.total, s.pending, s.approved, s.rejected, 1);
  setBar("#barTotal", s.total, max);
  setBar("#barPending", s.pending, max);
  setBar("#barApproved", s.approved, max);
  setBar("#barRejected", s.rejected, max);
}

async function loadRows() {
  const q = encodeURIComponent($("#search").value.trim());
  const data = await api(`/api/requests?q=${q}`);
  latestRows = data;
  updatePlatformCards(data);

  rows.innerHTML = data.map(r => `
    <tr>
      <td><strong>${escapeHtml(r.game_name)}</strong></td>
      <td>${escapeHtml(r.discord_username)}</td>
      <td>${escapeHtml(r.platform)}</td>
      <td>${escapeHtml(r.server_name)}</td>
      <td>${statusBadge(r.status)}</td>
      <td>${syncBadge(r.nitrado_sync_status, r.nitrado_sync_message)}</td>
      <td>${safeDate(r.created_at)}</td>
      <td>
        <div class="actions">
          <button class="small ok" onclick="approve(${r.id})">✓</button>
          <button class="small no" onclick="rejectReq(${r.id})">✕</button>
          <button class="small del" onclick="removeReq(${r.id})">Suppr.</button>
        </div>
      </td>
    </tr>
  `).join("") || `<tr><td colspan="8" class="muted">Aucune demande trouvée.</td></tr>`;
}

function setNitradoMessage(text, isError = false) {
  const el = $("#nitradoMessage");
  if (!el) return;
  el.textContent = text;
  el.style.color = isError ? "#ff7c85" : "";
}

async function loadNitrado() {
  const stateEl = $("#nitradoState");
  const accountEl = $("#nitradoAccount");
  const connectBtn = $("#connectNitradoBtn");
  const disconnectBtn = $("#disconnectNitradoBtn");
  const config = $("#nitradoConfig");
  const select = $("#nitradoService");
  const fileInput = $("#nitradoWhitelistFile");
  if (!stateEl) return;

  try {
    const status = await api("/api/nitrado/status");
    if (!status.configured) {
      stateEl.textContent = "À configurer";
      stateEl.className = "nitrado-state offline";
      accountEl.textContent = "OAuth Nitrado non configuré";
      connectBtn.classList.add("is-disabled");
      setNitradoMessage("Ajoute NITRADO_CLIENT_ID, NITRADO_CLIENT_SECRET et PUBLIC_BASE_URL dans Railway.");
      return;
    }

    connectBtn.classList.remove("is-disabled");
    if (!status.connected) {
      stateEl.textContent = "Non connecté";
      stateEl.className = "nitrado-state offline";
      accountEl.textContent = "Aucun compte Nitrado";
      connectBtn.classList.remove("hidden");
      disconnectBtn.classList.add("hidden");
      config.classList.add("hidden");
      setNitradoMessage("Le propriétaire autorise DayZ Gate via OAuth2.");
      return;
    }

    stateEl.textContent = "Connecté";
    stateEl.className = "nitrado-state online";
    accountEl.textContent = status.user?.username ? `Compte : ${status.user.username}` : "Compte Nitrado connecté";
    connectBtn.classList.add("hidden");
    disconnectBtn.classList.remove("hidden");
    config.classList.remove("hidden");
    fileInput.value = status.selected?.whitelistFile || "dayzstandalone/whitelist.txt";
    setNitradoMessage(status.apiError ? `Connecté, mais API : ${status.apiError}` : "Connexion sécurisée active.", Boolean(status.apiError));

    try {
      const services = await api("/api/nitrado/services");
      select.innerHTML = services.map(s => {
        const selected = String(status.selected?.serviceId) === String(s.id) ? " selected" : "";
        return `<option value="${escapeHtml(s.id)}" data-label="${escapeHtml(s.label)}"${selected}>${escapeHtml(s.label)} — #${escapeHtml(s.id)}</option>`;
      }).join("") || '<option value="">Aucun service trouvé</option>';
    } catch (err) {
      select.innerHTML = '<option value="">Impossible de charger les services</option>';
      setNitradoMessage(err.message, true);
    }
  } catch (err) {
    stateEl.textContent = "Erreur";
    stateEl.className = "nitrado-state offline";
    setNitradoMessage(err.message, true);
  }
}

async function refresh() {
  await Promise.all([loadStats(), loadRows(), loadNitrado()]);
}

window.approve = async id => {
  try {
    const result = await api(`/api/requests/${id}/approve`, { method: "POST" });
    if (result.nitrado?.status === "error") setNitradoMessage(`Validation faite, erreur Nitrado : ${result.nitrado.message}`, true);
    else if (result.nitrado?.message) setNitradoMessage(result.nitrado.message);
    await Promise.all([loadStats(), loadRows()]);
  } catch (err) {
    alert(err.message);
  }
};

window.rejectReq = async id => {
  await api(`/api/requests/${id}/reject`, { method: "POST" });
  await Promise.all([loadStats(), loadRows()]);
};

window.removeReq = async id => {
  if (!confirm("Supprimer cette demande ?")) return;
  await api(`/api/requests/${id}`, { method: "DELETE" });
  await Promise.all([loadStats(), loadRows()]);
};

$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("#loginError").textContent = "";
  try {
    await api("/api/login", {
      method: "POST",
      body: JSON.stringify({ username: $("#username").value, password: $("#password").value })
    });
    loginView.classList.add("hidden");
    dashboardView.classList.remove("hidden");
    await refresh();
  } catch (err) {
    $("#loginError").textContent = err.message;
  }
});

$("#logoutBtn").addEventListener("click", async () => {
  await api("/api/logout", { method: "POST" });
  location.reload();
});

$("#refreshBtn").addEventListener("click", refresh);
$("#search").addEventListener("input", () => {
  clearTimeout(window._searchTimer);
  window._searchTimer = setTimeout(loadRows, 250);
});

$("#saveNitradoServerBtn")?.addEventListener("click", async () => {
  const select = $("#nitradoService");
  const option = select.options[select.selectedIndex];
  if (!select.value) return setNitradoMessage("Choisis un serveur Nitrado.", true);
  try {
    await api("/api/nitrado/select", {
      method: "POST",
      body: JSON.stringify({
        serviceId: select.value,
        serviceLabel: option?.dataset?.label || option?.textContent || "",
        whitelistFile: $("#nitradoWhitelistFile").value.trim()
      })
    });
    setNitradoMessage("Serveur Nitrado enregistré.");
    await loadNitrado();
  } catch (err) {
    setNitradoMessage(err.message, true);
  }
});

$("#disconnectNitradoBtn")?.addEventListener("click", async () => {
  if (!confirm("Déconnecter le compte Nitrado de DayZ Gate ?")) return;
  await api("/api/nitrado/disconnect", { method: "POST" });
  await loadNitrado();
});

(async () => {
  await loadPublicConfig();
  const me = await api("/api/me");
  if (me.loggedIn) {
    loginView.classList.add("hidden");
    dashboardView.classList.remove("hidden");
    await refresh();
  }
})();
